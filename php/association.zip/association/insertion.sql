use association;
-- table adherent
/*insert into adherent(nom,prenom, date_naissance) 
			values('Jung','Stéphanie','1976-03-11'),
				  ('Saihi','Dorra','1986-02-09'),
                  ('Berkane','Chihab','1990-05-22'),
                  ('Bouzam','Youcef','1996-04-05'),
                  ('','Nicolas','1980-07-08'),
				  ('Sanchez','Paul','1989-03-15'),
				  ('','Gregoire','1990-06-12'),
                  ('','Gregory','2018-04-13'),
				  ('','Mathias','1996-02-14'),
				  ('Foureur','Manu','1997-01-10'),
				  ('','Maxime','1993-09-17'),
                   ('','Frederic','1980-07-07'),
				  ('Perisse','Sébastien','1975-05-18'),
				   ('Blaudez','Nicolas','1982-11-10'),
				   ('Domenjoud','Yannick','1985-09-08'),
                   ('Balzer','Antoine','1973-02-01'),
                    ('Charalambides','OLivier','1970-08-01')*/
-- table typeAdherant
-- insert into typeAdherent (typeAdherent) values ('dirigeant'),('Prof'),('participant');
-- table role
-- insert into role (idtypeAdherent, id_adherent) values (3,1), (3,2),(3,3),(3,4),(3,5),(3,7),(3,8),(3,9),(3,11),(3,12);
/*insert into role (idtypeAdherent, id_adherent) values (1,6),(3,6);
insert into role (idtypeAdherent, id_adherent) values (1,10),(3,10);
insert into role (idtypeAdherent, id_adherent) values (1,13),(2,13);
insert into role (idtypeAdherent, id_adherent) values (2,14),(3,14);
insert into role (idtypeAdherent, id_adherent) values (2,15),(3,15);
insert into role (idtypeAdherent, id_adherent) values (2,16),(3,16);
insert into role (idtypeAdherent, id_adherent) values (2,17),(1,17);*/
-- table planning
-- insert into planning (date_planning) values ('2018-04-10'),('2018-04-11'),('2018-04-12'),('2018-04-13')
-- table typeActivite
-- insert into typeActivite (typeActivite) values ('PEINTURE SUR SOIE'),('DANSE LATINE'),('AIKIDO'),('PHILOSOPHIE ASIATIQUE')
-- table activite
/*insert into activite(idtypeActivite,id_prof,heureDebut,dateFin,idplanning)
						values(1,14,'19:00:00','21:00:00',1),
							  (2,17,'20:30:00','22:30:00',2),
                              (3,16,'20:30:00','22:30:00',3),
							  (4,15,'20:30:00','22:30:00',4)*/
-- table participant
/*insert into participant (id_adherent,id_activite) 
            values (6,1), (6,4),(7,1),(7,4),(8,1),(8,4),(9,1),(9,4),(15,1),
                   (1,2),(1,4),(2,2),(2,4),(5,2),(5,4),(12,2),(12,4),(13,2),
                   (3,3),(3,4),(4,3),(4,4),(11,3),(11,4),(14,3)*/
								
